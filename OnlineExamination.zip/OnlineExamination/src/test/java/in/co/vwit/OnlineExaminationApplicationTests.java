package in.co.vwit;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import in.co.vwit.layer2.Question;
import in.co.vwit.layer3.QuestionRepository;

@SpringBootTest
class OnlineExaminationApplicationTests {

	@Autowired
	QuestionRepository quesRepo;
	
	@Test
	void contextLoads() {
		Question q = new Question();
		q.setAnswer("2");
		q.setOption1("a");
		q.setOption2("b");
		q.setOption3("c");
		q.setOption4("d");
		q.setQuestionText("Question");
		
		//ur side nw issue
		quesRepo.addQuestion(q);
	}

}
