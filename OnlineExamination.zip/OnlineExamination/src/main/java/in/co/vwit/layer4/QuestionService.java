package in.co.vwit.layer4;

import in.co.vwit.layer2.Question;

public interface QuestionService {
	
	public Question createQuestion(Question questionToBeCreated);
	
}
