package in.co.vwit.layer3;

import in.co.vwit.layer2.Question;

public interface QuestionRepository {
	
	public Question addQuestion(Question questionToBeAdded);
	
}
