package in.co.vwit.layer4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.co.vwit.layer2.Question;
import in.co.vwit.layer3.QuestionRepository;

@Service
public class QuestionServiceImpl implements QuestionService {

	@Autowired
	QuestionRepository questionRepo;
	
	public QuestionServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Question createQuestion(Question questionToBeCreated) {
		System.out.println("QuestionService: createQuestion");
		return questionRepo.addQuestion(questionToBeCreated);
	}

}
