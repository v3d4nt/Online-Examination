package in.co.vwit.layer3;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import in.co.vwit.layer2.Question;

@Repository
public class QuestionRepositoryImpl implements QuestionRepository{

	@PersistenceContext
	EntityManager entityManager;
	
	public QuestionRepositoryImpl(){
		
	}

	@Override
	@Transactional
	public Question addQuestion(Question questionToBeAdded) {
		entityManager.persist(questionToBeAdded);
		return questionToBeAdded;
	}

}
