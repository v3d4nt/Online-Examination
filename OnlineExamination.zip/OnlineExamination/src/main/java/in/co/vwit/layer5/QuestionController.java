package in.co.vwit.layer5;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.co.vwit.layer2.Question;
import in.co.vwit.layer4.QuestionService;

@CrossOrigin
@RestController
@RequestMapping("/question")
public class QuestionController {
	
	@Autowired
	QuestionService questionService;
	
	

	public QuestionController() {
		System.out.println("QuestionControllerJPA: constructor...");
	}
	
	@PostMapping("/addQuestion")
	public Question addQuestion(@RequestBody Question questionToBeAdded) {
		Question tempQuestion = new Question();
		tempQuestion.setQuestionText(questionToBeAdded.getQuestionText());
		tempQuestion.setOption1(questionToBeAdded.getOption1());
		tempQuestion.setOption2(questionToBeAdded.getOption2());
		tempQuestion.setOption3(questionToBeAdded.getOption3());
		tempQuestion.setOption4(questionToBeAdded.getOption4());
		tempQuestion.setAnswer(questionToBeAdded.getAnswer());
		questionService.createQuestion(tempQuestion);
		return questionToBeAdded;
	}

}
