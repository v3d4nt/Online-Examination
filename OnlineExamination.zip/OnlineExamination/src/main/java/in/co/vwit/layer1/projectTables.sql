CREATE DATABASE IF NOT EXISTS online_exam;

USE online_exam;

CREATE TABLE IF NOT EXISTS question (
	question_id INT PRIMARY KEY, 
	subject_id INT,
	question_text VARCHAR(100),
	option_1 VARCHAR(30),
	option_2 VARCHAR(30),
	option_3 VARCHAR(30),
	option_4 VARCHAR(30),
	answer INT
);